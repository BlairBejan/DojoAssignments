namespace log_reg.Models
{
    public abstract class BaseEntity 
    {  
    }
}