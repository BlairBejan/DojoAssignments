
namespace pokeinfo{
    public class PokeData{
        public string Name {get; set;}
        public string Type {get; set;}
        public long Height {get; set;}
        public long Weight {get; set;}
    }
}