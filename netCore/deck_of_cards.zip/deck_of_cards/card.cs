using System;
namespace deck_of_cards{
    public class card{
        public string stringVal;
        public int suit;
        public int val;
        public card(int Suit, int Val){
            suit = Suit;
            val = Val;
        }

    }
}