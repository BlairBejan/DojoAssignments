﻿using System;

namespace deck_of_cards
{
    class Program
    {
        static void Main(string[] args)
        {
            deck mydeck = new deck();
        }
    }
}
